<html>
    <head>Headings</head>
    <body>
    <?php
        for($i=1; $i <= 6; $i++){
            echo "<h".$i.">Heading ".$i."</h".$i.">";
        }
    ?>
    </body>
</html>