<?php
function gandakanString($s, $n) {
    for ($i=0; $i < $n; $i++) { 
        echo $s;
    }
}
gandakanString('Hello',3)
?>