<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Kalkulator Sederhana</h1>

	<form method="post" action="hitung2.php">
		Bilangan 1 <input type="text" name="bil1"> <br>
		Bilangan 2 <input type="text" name="bil2"> <br><br>
		<input type="submit" name="penjumlahan" value="+">
		<input type="submit" name="pengurangan" value="-">
		<input type="submit" name="perkalian" value="x">
		<input type="submit" name="pembagian" value="/">		
		<input type="submit" name="pangkat" value="^">	
	</form>
</body>
</html>
